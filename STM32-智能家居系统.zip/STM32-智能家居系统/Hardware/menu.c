#include "stm32f10x.h"                  // Device header
#include "OLED.H"
#include "dht11.h"
#include "bh1750.h"
#include "LED.H"
#include "Key.H"
#include "menu.h"
#include "motor.h"

typedef void (*MenuFunction)(void);

MenuFunction menu_table[2][4] = {
	{ level1_option1, level1_option2, level1_option3, level1_option4 },
	{ level2_option1, level2_option2, level2_option3, level2_option4 }
};

void level1_option1(void)
{
	OLED_Clear();
	OLED_ShowPoint(1,1);
	OLED_ShowString(1,2,"Temp:");
	OLED_ShowString(2,2,"Humi:");
	OLED_ShowString(3,2,"Light:");
	OLED_ShowString(4,2,"Function");
	OLED_ShowNum(1,7,DHT11_Data.temp_int,2);
	OLED_ShowString(1,9,".");
	OLED_ShowNum(1,10,DHT11_Data.temp_deci,1);
	OLED_ShowString(1,11,"'C");
	OLED_ShowNum(2,7,DHT11_Data.humi_int,2);
	OLED_ShowString(2,9,"%");
	OLED_ShowNum(3,8,light,5);
	OLED_ShowString(3,13,"LX");
}
void level1_option2(void)
{
	OLED_Clear();
	OLED_ShowPoint(2,1);
	OLED_ShowString(1,2,"Temp:");
	OLED_ShowString(2,2,"Humi:");
	OLED_ShowString(3,2,"Light:");
	OLED_ShowString(4,2,"Function");
	OLED_ShowNum(1,7,DHT11_Data.temp_int,2);
	OLED_ShowString(1,9,".");
	OLED_ShowNum(1,10,DHT11_Data.temp_deci,1);
	OLED_ShowString(1,11,"'C");
	OLED_ShowNum(2,7,DHT11_Data.humi_int,2);
	OLED_ShowString(2,9,"%");
	OLED_ShowNum(3,8,light,5);
	OLED_ShowString(3,13,"LX");
}
void level1_option3(void)
{
	OLED_Clear();
	OLED_ShowPoint(3,1);
	OLED_ShowString(1,2,"Temp:");
	OLED_ShowString(2,2,"Humi:");
	OLED_ShowString(3,2,"Light:");
	OLED_ShowString(4,2,"Function");
	OLED_ShowNum(1,7,DHT11_Data.temp_int,2);
	OLED_ShowString(1,9,".");
	OLED_ShowNum(1,10,DHT11_Data.temp_deci,1);
	OLED_ShowString(1,11,"'C");
	OLED_ShowNum(2,7,DHT11_Data.humi_int,2);
	OLED_ShowString(2,9,"%");
	OLED_ShowNum(3,8,light,5);
	OLED_ShowString(3,13,"LX");
}
void level1_option4(void)
{
	OLED_Clear();
	OLED_ShowPoint(4,1);
	OLED_ShowString(1,2,"Temp:");
	OLED_ShowString(2,2,"Humi:");
	OLED_ShowString(3,2,"Light:");
	OLED_ShowString(4,2,"Function");
	OLED_ShowNum(1,7,DHT11_Data.temp_int,2);
	OLED_ShowString(1,9,".");
	OLED_ShowNum(1,10,DHT11_Data.temp_deci,1);
	OLED_ShowString(1,11,"'C");
	OLED_ShowNum(2,7,DHT11_Data.humi_int,2);
	OLED_ShowString(2,9,"%");
	OLED_ShowNum(3,8,light,5);
	OLED_ShowString(3,13,"LX");
}
void level2_option1(void)
{
	OLED_Clear();
	OLED_ShowPoint(1,1);
	OLED_ShowString(1,2,"LED1:");
	OLED_ShowNum(1,7,led1_state,1);
	OLED_ShowString(2,2,"LED2:");
	OLED_ShowNum(2,7,led2_state,1);
	OLED_ShowString(3,2,"LED3:");
	OLED_ShowNum(3,7,led3_state,1);
	OLED_ShowString(4,2,"FAN:");
	OLED_ShowNum(4,6,fan_level,1);
}
void level2_option2(void)
{
	OLED_Clear();
	OLED_ShowPoint(2,1);
	OLED_ShowString(1,2,"LED1:");
	OLED_ShowNum(1,7,led1_state,1);
	OLED_ShowString(2,2,"LED2:");
	OLED_ShowNum(2,7,led2_state,1);
	OLED_ShowString(3,2,"LED3:");
	OLED_ShowNum(3,7,led3_state,1);
	OLED_ShowString(4,2,"FAN:");
	OLED_ShowNum(4,6,fan_level,1);
}
void level2_option3(void)
{
	OLED_Clear();
	OLED_ShowPoint(3,1);
	OLED_ShowString(1,2,"LED1:");
	OLED_ShowNum(1,7,led1_state,1);
	OLED_ShowString(2,2,"LED2:");
	OLED_ShowNum(2,7,led2_state,1);
	OLED_ShowString(3,2,"LED3:");
	OLED_ShowNum(3,7,led3_state,1);
	OLED_ShowString(4,2,"FAN:");
	OLED_ShowNum(4,6,fan_level,1);
}
void level2_option4(void)
{
	OLED_Clear();
	OLED_ShowPoint(4,1);
	OLED_ShowString(1,2,"LED1:");
	OLED_ShowNum(1,7,led1_state,1);
	OLED_ShowString(2,2,"LED2:");
	OLED_ShowNum(2,7,led2_state,1);
	OLED_ShowString(3,2,"LED3:");
	OLED_ShowNum(3,7,led3_state,1);
	OLED_ShowString(4,2,"FAN:");
	OLED_ShowNum(4,6,fan_level,1);
}