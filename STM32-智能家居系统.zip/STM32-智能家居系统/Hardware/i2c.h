#ifndef _I2C_H_
#define _I2C_H_

void I2C_W_SCL(uint8_t BitValue);
void I2C_W_SDA(uint8_t BitValue);
uint8_t I2C_R_SDA(void);
void I2C_INIT(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_SendByte(uint8_t Byte);
uint8_t I2C_ReceiveByte(void);
void I2C_SendAck(uint8_t ack);
uint8_t I2C_ReceiveAck(void);
void SDA_IN(void);
void SDA_OUT(void);
#endif