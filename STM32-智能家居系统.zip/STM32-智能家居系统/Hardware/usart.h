#ifndef _USART_H_
#define _USART_H_

#include "stm32f10x.h"                  // Device header

#define USART_DEBUG		USART1

void Usart1_Init(uint32_t BAUD);
void Usart2_Init(uint32_t BAUD);
void Usart_SendString(USART_TypeDef *USARTx, unsigned char *str, unsigned short len);
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...);
void USART1_IRQHandler(void);

#endif