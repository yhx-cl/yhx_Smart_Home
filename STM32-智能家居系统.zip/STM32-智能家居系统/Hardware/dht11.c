#include "stm32f10x.h"                  // Device header
#include "delay.h"
#include "dht11.h"

#define DHT11_DATA				GPIO_Pin_7
#define DHT11_RCC				RCC_APB2Periph_GPIOA
#define DHT11_GPIO				GPIOA
#define DHT11_DATA_OUT(x)		GPIO_WriteBit(DHT11_GPIO, DHT11_DATA, (BitAction)(x))
#define DHT11_R_DATA()			GPIO_ReadInputDataBit(DHT11_GPIO, DHT11_DATA)

DHT11_Data_TypeDef DHT11_Data;
double temp;


void DHT11_Init(void)
{
	RCC_APB2PeriphClockCmd(DHT11_RCC, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = DHT11_DATA;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_GPIO, &GPIO_InitStructure);
	
	DHT11_DATA_OUT(1);
}

void DHT11_Mode_IPU(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = DHT11_DATA;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_GPIO, &GPIO_InitStructure);
}

void DHT11_Mode_OUT_PP(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = DHT11_DATA;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(DHT11_GPIO, &GPIO_InitStructure);
}
uint8_t DHT11_ReceiveByte(void)
{
	uint8_t i,Byte=0x00;
	for(i=0;i<8;i++)
	{
		while(!DHT11_R_DATA());
		Delay_us(30);
		if(DHT11_R_DATA())
		{
			while(DHT11_R_DATA());
			Byte |= 0x01 << (7-i);
		}
		else
		{
			Byte |= 0x00 << (7-i);
		}
	}
	return Byte;
}
uint8_t DHT11_ReceiveData(DHT11_Data_TypeDef *DHT11_Data)
{
	DHT11_Mode_OUT_PP();
	DHT11_DATA_OUT(0);
	Delay_ms(20);
	DHT11_DATA_OUT(1);
	Delay_us(30);
	DHT11_Mode_IPU();
	if(DHT11_R_DATA() == 0)
	{
		while(!DHT11_R_DATA());
		while(DHT11_R_DATA());
		DHT11_Data -> humi_int = DHT11_ReceiveByte();
		DHT11_Data -> humi_deci = DHT11_ReceiveByte();
		DHT11_Data -> temp_int = DHT11_ReceiveByte();
		DHT11_Data -> temp_deci = DHT11_ReceiveByte();
		DHT11_Data -> check_sum= DHT11_ReceiveByte();
		DHT11_Mode_OUT_PP();
		DHT11_DATA_OUT(1);
		if(DHT11_Data -> check_sum == DHT11_Data -> humi_int + DHT11_Data -> humi_deci + DHT11_Data -> temp_int + DHT11_Data -> temp_deci)
		{
			temp = (double) DHT11_Data->temp_int + (double) (DHT11_Data->temp_deci/10.0);
			return 1;
		}		
				
			else 
				return 0;
	}
	return 0;
}