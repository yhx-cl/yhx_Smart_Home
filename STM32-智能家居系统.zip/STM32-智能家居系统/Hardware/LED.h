#ifndef __LED_H
#define __LED_H

#define LED_ON		0
#define	LED_OFF		1

extern _Bool led1_state,led2_state,led3_state;

void LED_Init(void);
void LED1_Set(_Bool State);
void LED2_Set(_Bool State);
void LED3_Set(_Bool State);

#endif
