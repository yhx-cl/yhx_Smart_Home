#include "stm32f10x.h"                  // Device header
#include "LED.h"                  
#include "Key.h"

_Bool led1_state;
_Bool led2_state;
_Bool led3_state;

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	LED1_Set(LED_OFF);
	LED2_Set(LED_OFF);
	LED3_Set(LED_OFF);
}

void LED1_Set(_Bool State)
{
	led1_state = !State;
	GPIO_WriteBit(GPIOB, GPIO_Pin_13,State);
}
void LED2_Set(_Bool State)
{
	led2_state = !State;
	GPIO_WriteBit(GPIOB, GPIO_Pin_14,State);
}

void LED3_Set(_Bool State)
{
	led3_state = !State;
	GPIO_WriteBit(GPIOB, GPIO_Pin_15,State);
}

