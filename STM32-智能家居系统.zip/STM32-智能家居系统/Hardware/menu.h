#ifndef _MENU_H_
#define _MENU_H_

typedef void (*MenuFunction)(void);

extern MenuFunction menu_table[2][4];

void level1_option1(void);
void level1_option2(void);
void level1_option3(void);
void level1_option4(void);
void level2_option1(void);
void level2_option2(void);
void level2_option3(void);
void level2_option4(void);

#endif