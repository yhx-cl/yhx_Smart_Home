#include "stm32f10x.h"                  // Device header
#include "i2c.h"
#include "delay.h"
#include "bh1750.h"
#include "usart.h"

#define BH1750_1LX			0x10
#define BH1750_ADDR			0x46
#define BH1750_Pow			0x01
#define BH1750_Reset		0x07

uint16_t light;

void BH1750_Start(void)
{
	I2C_Start();
	I2C_SendByte(BH1750_ADDR);
	if(I2C_ReceiveAck() != 0) 
	{
		UsartPrintf(USART_DEBUG, "Start BH1750 ERROR!1");
		return;
	}
	I2C_SendByte(BH1750_Pow);
	if(I2C_ReceiveAck() != 0) 
	{
		UsartPrintf(USART_DEBUG, "Start BH1750 ERROR2!\r\n");
		return;
	}
	I2C_Stop();
	
	I2C_Start();
	I2C_SendByte(BH1750_ADDR);
	if(I2C_ReceiveAck() != 0) 
	{
		UsartPrintf(USART_DEBUG, "Start BH1750 ERROR3!\r\n");
		return;
	}
	I2C_SendByte(BH1750_1LX);
	if(I2C_ReceiveAck() != 0) 
	{
		UsartPrintf(USART_DEBUG, "Start BH1750 ERROR4!\r\n");
		return;
	}
	I2C_Stop();
	
	Delay_ms(180);
}

uint16_t BH1750_ReadData(void)
{
	uint16_t Data = 0,timeout = 3;
	do{
		timeout--;
		I2C_Start();
		I2C_SendByte(BH1750_ADDR | 0x01);
		if(timeout == 0)
		{
			UsartPrintf(USART_DEBUG, "Read BH1750 ERROR!\r\n");
			return 1;
		}
	}while(I2C_ReceiveAck() != 0 && timeout > 0);
	Data = I2C_ReceiveByte() << 8;
	UsartPrintf(USART_DEBUG, "Data: %d\r\n",Data);
	I2C_SendAck(0);
	Data |= I2C_ReceiveByte();
	UsartPrintf(USART_DEBUG, "Data: %d\r\n",Data);
	I2C_SendAck(1);
	I2C_Stop();
	light = (uint16_t)(Data/1.2);
	return light;
}