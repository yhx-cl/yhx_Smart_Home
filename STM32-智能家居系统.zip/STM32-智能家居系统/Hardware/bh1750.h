#ifndef _BH1750_H_
#define _BH1750_H_
#include "stm32f10x.h"                  // Device header

extern uint16_t light;

void BH1750_Start(void);
uint16_t BH1750_ReadData(void);

#endif