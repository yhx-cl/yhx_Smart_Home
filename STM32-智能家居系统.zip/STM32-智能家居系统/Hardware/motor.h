#ifndef _MOTOR_H_
#define _MOTOR_H_

extern unsigned char fan_level;

void PWM_Init(void);
void Motor_Init(void);
void Motor_SetPWM(unsigned char fan_level); 

#endif