#include "stm32f10x.h"                  // Device header
#include "delay.h"

#include "menu.h"
#include "OLED.h"
#include "i2c.h"
#include "dht11.h"
#include "bh1750.h"
#include "LED.h"
#include "Timer.h"
#include "onenet.h"
#include "esp8266.h"
#include "motor.h"

#include "usart.h"
#include "beep.h"
#include "Key.h"
//C��
#include <string.h>


//#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"www.yhxcl.cloud\",1883\r\n"
#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"broker.emqx.io\",1883\r\n"
#define DevSbuTopic				"$sys/VaCTB1CElJ/y1/thing/property/post/reply"

void Hardware_Init(void)
{
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	


	Usart1_Init(115200);							//����1����ӡ��Ϣ��
	
	Usart2_Init(115200);							//����2������ESP8266��
	
	UsartPrintf(USART_DEBUG, " Usart init OK\r\n");
	I2C_INIT();	
	
	UsartPrintf(USART_DEBUG, " I2C init OK\r\n");
	BH1750_Start();
	
	UsartPrintf(USART_DEBUG, " BH1750 init OK\r\n");
	Beep_Init();									
	LED_Init();
	Key_Init();
	Motor_Init();
	
	UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
	
}

int main(void)
{
	
	unsigned short timeCount = 0;	//���ͼ������
	
	unsigned char *dataPtr = NULL;
	
	u8 level = 0,option = 0,key = 0;
	
	OLED_Init();
	OLED_Clear();
	
	
	Hardware_Init();				//��ʼ����ΧӲ��
	 
	menu_table[level][option]();
	
	ESP8266_Init();					

	UsartPrintf(USART_DEBUG, "Connect MQTTs Server...\r\n");
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		Delay_ms(500);
	UsartPrintf(USART_DEBUG, "Connect MQTTs Server Success\r\n");
	while(OneNet_DevLink())			//����OneNET
		Delay_ms(500);
	UsartPrintf(USART_DEBUG, "Connect Onenet Success\r\n");
	OneNET_Subscribe(DevSbuTopic);
	while(1)
	{
		UsartPrintf(USART_DEBUG, "enter while\r\n");
		DHT11_ReceiveData(&DHT11_Data);
		BH1750_ReadData();
		if(++timeCount >= 40)									//���ͼ��6s
		{
			UsartPrintf(USART_DEBUG, "Temperature:%.1f Humidity:%d Light:%d LED1:%d LED2:%d LED3:%d fan:%d\r\n",temp,DHT11_Data.humi_int,light,led1_state,led2_state,led3_state,fan_level);
			UsartPrintf(USART_DEBUG, "OneNet_SendData\r\n");
			
			menu_table[level][option]();
			
			OneNet_SendData();									//��������
			
			timeCount = 0;
			ESP8266_Clear();
		}
		key = Key_GetNum();
		if(key != 0)
		{
			if(key == 1)
			{
				option = (option+3)%4;
				menu_table[level][option]();
			}
			if(key == 2)
			{
				if(level == 0 && option == 3)
				{
					level ++,option = 0;
					menu_table[level][option]();
				}
				else if(level == 1 && option == 0)
				{
					LED1_Set(led1_state);
					menu_table[level][option]();
				}
				else if(level == 1 && option == 1)
				{
					LED2_Set(led2_state);
					menu_table[level][option]();
				}
				else if(level == 1 && option == 2)
				{
					LED3_Set(led3_state);
					menu_table[level][option]();
				}
				else if(level == 1 && option == 3)
				{
					fan_level = (fan_level+5)%4;
					Motor_SetPWM(fan_level);
					menu_table[level][option]();
				}
			}
			if(key == 3)
			{
				option = (option+5)%4;
				menu_table[level][option]();
			}
			if(key == 4 && level > 0)
			{
				level --,option = 0;
				menu_table[level][option]();
			}
		}
		dataPtr = ESP8266_GetIPD(4);
		if(dataPtr != NULL)
			OneNet_RevPro(dataPtr);
		
		Delay_ms(10);
	}

}