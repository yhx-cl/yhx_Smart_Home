// index.js

const app = getApp() 
const { connect } = require('../../utils/mqtt')

const mqttHost = 'broker.emqx.io'
const mqttPort = 8084

const devicePubTopic = '$sys/VaCTB1CElJ/y1/thing/property/post'
const deviceSubTopic = '$sys/VaCTB1CElJ/y1/thing/property/post/reply'

const mpSubTopic = devicePubTopic
const mpPubTopic = deviceSubTopic

const heFengKey = '1b9d280ef5c64c9595f5ce2235c22fba'

const hefengFreeApi = "https://n83qqq4y2h.re.qweatherapi.com/v7"; //  和风天气免费API前缀
const geoApi = "https://n83qqq4y2h.re.qweatherapi.com/geo/v2/city/lookup?" //  地理位置api（用来获取经纬度对应的城市/城区名字）

Page({
  data: {
    client: null,
    temp: 0,
    humi: 0,
    light: 0,
    led1: false,
    led2: false,
    led3: false,
    beep: false,
    fan_level: 0,
    airQuality: "请求中",
    area: "请求中",
    city: "请求中",
    temperature: "请求中",
    suggestion: "请求中",
    perTemp: "请求中",
    pm: "请求中",
    loading: false
  },
  
  onLed1Change(event) {
    const that = this
    console.log(event.detail.value)
    const sw = event.detail.value
    that.setData({led1: sw})
    
    if(sw) {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "led1",
        value: 1
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---开客厅灯")
        }
      })
    } else {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "led1",
        value: 0
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---关客厅灯")
        }
      })
    }
  },
  onLed2Change(event) {
    const that = this
    console.log(event.detail.value)
    const sw = event.detail.value
    that.setData({led2: sw})
    
    if(sw) {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "led2",
        value: 1
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---开卧室灯")
        }
      })
    } else {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "led2",
        value: 0
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---关卧室灯")
        }
      })
    }
  },
  onLed3Change(event) {
    const that = this
    console.log(event.detail.value)
    const sw = event.detail.value
    that.setData({led3: sw})
    
    if(sw) {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "led3",
        value: 1
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---开厨房灯")
        }
      })
    } else {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "led3",
        value: 0
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---关厨房灯")
        }
      })
    }
  },
  onBeepChange(event) {
    const that = this
    console.log(event.detail.value)
    const sw = event.detail.value
    that.setData({beep: sw})
    
    if(sw) {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "beep",
        value: 1
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---打开报警器")
        }
      })
    } else {
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "beep",
        value: 0
      }), function(err) {
        if(!err) {
          console.log("成功下发指令---关闭报警器")
        }
      })
    }
  },
  fanSpeedSub: function() {
    const that = this;
    if (that.data.fan_level > 0) {
      const newLevel = that.data.fan_level - 1;
      that.setData({
        fan_level: newLevel
      });

      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "fan_level",
        value: newLevel
      }), function(err) {
        if(!err) {
            if(newLevel != 0){
                console.log("成功下发指令---风扇档位设置为:" + newLevel)
            }
            else{
                console.log("成功下发指令---关闭风扇")
            }
        }
      })
    }
  },

  // 风扇加速函数
  fanSpeedAdd: function() {
    const that = this;
    if (that.data.fan_level < 3) {
      const newLevel = that.data.fan_level + 1;
      that.setData({
        fan_level: newLevel
      });
      
      // 直接在这里上传数据
      that.data.client.publish(mpPubTopic, JSON.stringify({
        target: "fan_level",
        value: newLevel
      }), function(err) {
        if(!err) {
            if(newLevel != 3){
                console.log("成功下发指令---风扇档位设置为:" + newLevel)
            }
            else{
                console.log("成功下发指令---风扇档位已达最大")
            }
        }
      })
    }
  },
  onShow() {
    const that = this
    
    // 显示连接服务器提示
    wx.showToast({
      title: "连接服务器....",
      icon: "loading",
      duration: 10000,
      mask: true,
    });
    
    let second = 5;
    that.toastTimer = setInterval(() => {
      second--;
      if (second) {
        wx.showToast({
          title: `连接服务器...${second}`,
          icon: "loading",
          duration: 1000,
          mask: true,
        });
      } else {
        clearInterval(that.toastTimer);
        wx.showToast({
          title: "连接失败",
          icon: "error",
          mask: true,
        });
      }
    }, 1000);
    
    // 连接MQTT服务器
    that.setData({
      client: connect(`wxs://${mqttHost}:${mqttPort}/mqtt`)
    })
    
    that.data.client.on('connect', function(params) {
      clearInterval(that.toastTimer)
      console.log("成功连接到MQTT服务器!");
      wx.showToast({
        title: '连接成功',
        icon: 'success',
        mask: true
      })
      
      // 订阅设备上行Topic
      that.data.client.subscribe(mpSubTopic, function(err) {
        if(!err) {
          console.log("成功订阅设备上行Topic!")
        }
      })
    })
    
    // 处理MQTT消息
    that.data.client.on('message', function(topic, message) {
      console.log(topic);
      let dataFormDev = {}
      try {
        dataFormDev = JSON.parse(message)
        console.log(dataFormDev);
        that.setData({
          temp: dataFormDev.temp,
          humi: dataFormDev.humi,
          light: dataFormDev.light,
          led1: dataFormDev.led1,
          led2: dataFormDev.led2,
          led3: dataFormDev.led3,
          beep: dataFormDev.beep,
          fan_level : dataFormDev.fan_level
        })
      } catch (error) {
        console.log("JSON解析失败!", error);
      } 
    })
    // 获取位置信息
    this.getLocation();
  },
// 获取地理位置
getLocation() {
  const that = this;
  that.setData({ 
    loading: true,
    area: '定位中...',
    city: '定位中...'
  });
  
  wx.getLocation({
    type: 'wgs84',
    success(res) {
      const { latitude, longitude } = res;
      that.getCityName(latitude, longitude);
    },
    fail(err) {
      console.error('定位失败:', err);
      that.setData({ 
        loading: false,
        area: '定位失败',
        city: '定位失败'
      });
      wx.showToast({
        title: '定位失败',
        icon: 'none',
        duration: 2000
      });
    }
  });
},

// 获取城市名称
getCityName(latitude, longitude) {
  const that = this;
  const url = `${geoApi}location=${longitude},${latitude}&key=${heFengKey}`;
  
  wx.request({
    url: url,
    success(res) {
      // 简化处理：只有获取到有效数据才算成功
      if (res.data && res.data.location && res.data.location.length > 0) {
        const location = res.data.location[0];
        that.setData({
          area: location.name,
          city: location.adm2,
        });
        
        // 获取天气信息
        that.getWeatherInfo(location.id);
      } else {
        // 视为失败
        that.handleLocationError();
      }
    },
    fail(err) {
      // 所有失败情况统一处理
      that.handleLocationError();
    }
  });
},

// 获取天气信息
getWeatherInfo(cityId) {
  const that = this;
  
  // 请求天气实况
  wx.request({
    url: `${hefengFreeApi}/weather/now?location=${cityId}&key=${heFengKey}`,
    success(res) {
      if (res.data && res.data.code === '200') {
        that.setData({
          temperature: `${res.data.now.temp}°C`,
          weather: res.data.now.text,
          perTemp: res.data.now.feelsLike
        });
      } else {
        that.setData({
            temperature: '获取失败',
            weather: '获取失败',
            perTemp: '获取失败'
        });
      }
    },
    fail() {
      that.setData({
        temperature: '获取失败',
        weather: '获取失败',
        perTemp: '获取失败'
      });
    }
  });
  
  // 请求空气质量
  wx.request({
    url: `${hefengFreeApi}/air/now?location=${cityId}&key=${heFengKey}`,
    success(res) {
      if (res.data && res.data.code === '200') {
        that.setData({
          airQuality: res.data.now.category || '获取失败',
          pm: res.data.now.pm2p5
        });
      } else {
        that.setData({
          airQuality: '获取失败',
          pm: '获取失败'
        });
      }
    },
    fail() {
      that.setData({
        airQuality: '获取失败',
        pm: '获取失败'
      });
    }
  });
  
  // 请求生活指数（舒适度）
  wx.request({
    url: `${hefengFreeApi}/indices/1d?type=8&location=${cityId}&key=${heFengKey}`,
    success(res) {
      if (res.data && res.data.code === '200' && res.data.daily && res.data.daily.length > 0) {
        that.setData({
          suggestion: res.data.daily[0].text || '获取失败'
        });
      } else {
        that.setData({
          suggestion: '获取失败'
        });
      }
    },
    fail() {
      that.setData({
        suggestion: '获取失败'
      });
    },
    complete() {
      // 所有请求完成后关闭加载状态
      that.setData({ loading: false });
    }
  });
},

// 统一的错误处理方法
handleLocationError() {
  this.setData({ 
    loading: false,
    area: '获取失败',
    city: '获取失败',
    airQuality: '获取失败',
    temperature: '获取失败',
    weather: '获取失败',
    suggestion: '获取失败'
  });
  wx.showToast({
    title: '位置信息获取失败',
    icon: 'none',
    duration: 2000
  });
}
})
