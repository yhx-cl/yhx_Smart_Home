// pages/my/my.js
const app = getApp()
const defaultAvatarUrl = '../../pic/userimage.png'

Page({
    data: {
      avatarUrl: '../../pic/userimage.png',
      version: '获取中...',
      system: '获取中...'
    },
  
    onLoad() {
      this.loadSystemInfo();
    },
  
    // 系统信息获取（独立封装）
    loadSystemInfo() {
      wx.getSystemInfo({
        success: (res) => {
          this.setData({ 
            version: res.version,
            system: res.system 
          });
        }
      });
    },
  
    // 终极版头像选择处理（完全静默错误）
    onChooseAvatar(e) {
      try {
        // 只有真实选择头像时才更新
        if (e.detail && e.detail.avatarUrl) {
          this.setData({ avatarUrl: e.detail.avatarUrl });
        }
      } catch (error) {
        // 完全吞掉所有错误（包括cancel）
        console.debug('用户取消选择头像'); // 可删除，仅调试用
      }
    },

  // 其他生命周期函数保持不变
  onReady() {},
  onShow() {},
  onHide() {},
  onUnload() {},
  onPullDownRefresh() {},
  onReachBottom() {},
  onShareAppMessage() {}
})